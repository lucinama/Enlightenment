UI screens for a media center using edje
